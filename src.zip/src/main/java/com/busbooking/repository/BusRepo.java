package com.busbooking.repository;
import com.busbooking.entity.Bus;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface BusRepo extends JpaRepository<Bus, Long> { }
