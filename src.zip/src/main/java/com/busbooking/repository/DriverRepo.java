package com.busbooking.repository;
import com.busbooking.entity.Driver;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface DriverRepo extends JpaRepository<Driver, Long> { }
